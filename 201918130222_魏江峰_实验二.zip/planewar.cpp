//#include"widget.h"
//#include"graphOBJ.h"
//#include<time.h>
//Enemy enemy;
//Plane plane;
//int score = 0;
//int toret = 0;
//int tox = 0; int toy = 0;
//bool niubi = false;
//float deltax;
//float deltay;
//int toshot = 0;
//void display()
//{
//	canvas.setColor(0, 0, 255);
//	toret++;
//	if (toret > 15)
//	{
//		plane.setColor(25, 120, 255);
//	}
//
//	for (int i = 0; i < mybullet.size(); i++)
//	{
//		fillRect(mybullet[i].x, mybullet[i].y, 8, 8);
//		if (enemy.area.inArea(mybullet[i].x, mybullet[i].y))
//		{
//			enemy.HP -= 10;
//			score += 8;
//			if (enemy.HP < 0)
//			{
//				tox = rand() % (win_width - 200) + 50;
//				toy = rand() % (win_height - 300) + 200;
//				deltax = (tox - enemy.posx) * 0.02;
//				deltay = (toy - enemy.posy) * 0.02;
//				score += 100;
//				enemy.HP = 1000;
//				enemy.moveto(rand() % (win_width - 200) + 100, rand() % (win_height - 300) + 200);
//			}
//		}
//	}
//
//	for (int i = 0; i < hisbullet.size(); i++)
//	{
//		canvas.setColor(255, 25, 125);
//		fillRect(hisbullet[i].X(), hisbullet[i].Y(), 8, 8);
//		if (plane.area.inArea(hisbullet[i].x, hisbullet[i].y))
//		{
//			if (!niubi)
//				plane.HP -= 100;
//			else plane.HP -= 10;
//			plane.setColor(255, 0, 2);
//			toret = 0;
//			if (plane.HP < 0)
//			{
//				canvas.killTimer();
//				canvas.setBGC(255, 0, 0);
//				canvas.setColor(255, 255, 255);
//				fillRect(200, 250, 220, 100);
//				canvas.setColor(0, 255, 0);
//				drawString(255, 310, "you died");
//				drawString(215, 270, "you got " + itos(score) + " score");
//				canvas.killEvent();
//				plane.onmove = 0;
//			}
//		}
//	}
//}
//
//
//void timer()
//{
//	++toshot;
//
//	if (toshot % 2 == 0)
//	{
//		hisbullet.push_back(bullets(enemy.posx - 3, enemy.posy - 58));
//	}
//
//	enemy.moveto(enemy.posx + deltax, enemy.posy + deltay);
//
//	if ((tox-plane.posx)* (tox - plane.posx)+ 
//		(toy - plane.posy)*(toy - plane.posy)<100000)
//	{
//		tox = rand() % (win_width - 100) + 50;
//		toy = rand() % (win_height - 300) + 200;
//		deltax = (tox - enemy.posx) * 0.02;
//		deltay = (toy - enemy.posy) * 0.02;
//	}
//
//	for (int i = 0; i < mybullet.size(); i++)
//	{
//		mybullet[i].y += 10;
//	}
//
//	if (!niubi)
//	{
//		if (toshot > 8)
//		{
//			toshot = 0;
//			mybullet.push_back(point(plane.posx - 3, plane.posy + 55));
//		}
//	}
//	else {
//		if (toshot > 2)
//		{
//			toshot = 0;
//			mybullet.push_back(point(plane.posx - 3, plane.posy + 55));
//			mybullet.push_back(point(plane.posx - 30, plane.posy + 55));
//			mybullet.push_back(point(plane.posx  +24, plane.posy + 55));
//		}
//	}
//	canvas.repaint();
//}
//
//int main()
//{
//	niubi = true;
//	srand(time(0));
//	enemy.moveto(400, 500);
//	tox = rand() % 300 + 200;
//	toy = rand() % 300 + 200;
//	deltax = (tox - enemy.posx) * 0.03;
//	deltay = (toy - enemy.posy) * 0.03;
//	Button btn("Start");
//	btn.moveto(500, 10);
//	bool start = false;
//	
//	btn.onclick = [=, &start](int b, int s, int x, int y)
//	{
//		if (!start)
//		{
//			canvas.setTimer(20, timer, 10);
//			start = true;
//			mouseHoverHandler = [=](int x, int y) {
//				plane.moveto(x, y);
//			};
//		}
//	};
//	btn.setMovable(false);
//
//	canvas.setWindowSize(600, 600);
//	canvas.setDisplayFunc(display);
//	canvas.setBGC(230, 230, 230);
//	canvas.eventloop();
//}